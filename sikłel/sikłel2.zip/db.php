<?php
	$db = [
		'host'=> 'localhost',
		'user'=> 'root',
		'password'=> '1234',
		'db'=> 'cms'
	];
?>